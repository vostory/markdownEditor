// Background Service Worker
console.log('X Comment Expander: Background Service Started');

// Listen for requests from content script
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === 'FETCH_COMMENTS') {
        handleFetchRequest(message, sender);
    }

    if (message.type === 'COMMENTS_EXTRACTED') {
        handleCommentsExtracted(message);
    }
});

async function handleFetchRequest(message, sender) {
    const { url, tweetId } = message;
    const senderTabId = sender.tab.id;

    // Create a minimized window to load the tweet
    // identifying it via a query param we hope X preserves, or just matching by URL
    // We'll append a hash which usually is preserved on client side routing
    const targetUrl = new URL(url);
    targetUrl.hash = '#x-fetcher-mode';

    try {
        const win = await chrome.windows.create({
            url: targetUrl.href,
            type: 'popup',
            width: 500, // Too small might be ignored or not render layout correctly
            height: 500,
            left: 0,
            top: 0,
            focused: false, // Don't steal focus
            state: 'normal' // 'minimized' causes macOS App Nap to freeze the tab
        });

        // Wait for the tab to be ready, then send the command
        // We can listen for tabs.onUpdated, but a short timeout is simpler for MVP
        setTimeout(() => {
            if (win.tabs && win.tabs.length > 0) {
                chrome.tabs.sendMessage(win.tabs[0].id, { type: 'COMMAND_SCRAPE_TWEET' });
            }
        }, 3000); // 3 seconds for initial load start

        // Store mapping: WindowID -> { SenderTabId, TweetId }
        // We'll prioritize closing this window once data is received
        // Or set a timeout
        setTimeout(() => {
            chrome.windows.remove(win.id).catch(() => { });
        }, 15000); // 15s hard timeout

    } catch (err) {
        console.error('Failed to create window:', err);
    }
}

async function handleCommentsExtracted(message) {
    const { comments, url, error } = message;

    // Find all tabs that might be waiting for this? 
    // Or broadcast?
    // We'll broadcast to all tabs on twitter.com
    const tabs = await chrome.tabs.query({ url: '*://*.x.com/*' }); // And twitter.com
    tabs.forEach(tab => {
        chrome.tabs.sendMessage(tab.id, {
            type: 'X_COMMENTS_DATA_RELAY',
            url,
            comments,
            error
        });
    });

    // Usage: The fetcher window (sender) should close itself?
    // We can't easily close "current window" from content script without `window.close` allowed (scripts can't close windows they didn't open, but this one was opened by script?)
    // Actually, `window.close()` works for popup windows opened by `window.open`. 
    // But here it was opened by extension.
    // So content script should send a message to background "I am done, kill me".

    if (message.windowId) {
        chrome.windows.remove(message.windowId).catch(() => { });
    }
}
