
// State to track processed tweets to avoid duplicate listeners
const processedTweets = new WeakSet();

// Constants
const BEARER_TOKEN = 'AAAAAAAAAAAAAAAAAAAAANRILgAAAAAAnNwIzUejRCOuH5E6I8xnZz4puTs%3D1Zv7ttfk8LF81IUq16cHjhLTvJu4FA33AGWWjCpTnA';

// ----------------------------------------------------------------------
// MAIN LOGIC
// ----------------------------------------------------------------------
function init() {
    console.log('Twitter Comment Expander: API Mode Initialized');

    // Inject Styles Programmatically to ensure update
    const style = document.createElement('style');
    style.textContent = `
    .x-comment-preview-container {
      margin-top: 12px !important;
      margin-bottom: 12px;
      margin-left: 12px;
      margin-right: 12px;
      background-color: rgba(29, 155, 240, 0.1) !important;
      border-radius: 12px;
      border: 1px solid rgba(29, 155, 240, 0.3) !important;
      border-left: 5px solid #1d9bf0 !important;
      padding: 12px;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
      font-size: 14px;
      line-height: 1.4;
      color: inherit;
      position: relative;
      z-index: 0;
    }
    .x-loading-spinner {
        font-size: 13px;
        color: #536471;
        display: flex;
        align-items: center;
        gap: 8px;
    }
    .x-comment-header {
        font-weight: bold;
        font-size: 15px;
        margin-bottom: 12px;
        color: inherit;
        opacity: 0.9;
        padding-bottom: 8px;
        border-bottom: 1px solid rgba(128,128,128,0.2);
    }
    .x-comment-item {
        margin-bottom: 12px;
    }
    .x-comment-author {
        font-weight: bold;
        font-size: 13px;
        margin-bottom: 2px;
    }
    .x-comment-text {
        font-size: 14px;
        word-wrap: break-word;
        white-space: pre-wrap;
        opacity: 0.95;
    }
  `;
    document.head.appendChild(style);

    const observer = new MutationObserver((mutations) => {
        const hasNewNodes = mutations.some(m => m.addedNodes.length > 0);
        if (hasNewNodes) {
            scanForTweets();
        }
    });

    observer.observe(document.body, { childList: true, subtree: true });
    scanForTweets();
}

function scanForTweets() {
    // Disable on Tweet Detail pages (User Request)
    // URL pattern: /username/status/123456
    // But allow /home, /explore, /profile
    if (location.pathname.includes('/status/')) return;

    const tweets = document.querySelectorAll('article[data-testid="tweet"]');
    tweets.forEach(tweet => {
        if (processedTweets.has(tweet)) return;

        const timeElement = tweet.querySelector('time');
        if (!timeElement) return;

        const linkElement = timeElement.closest('a');
        if (!linkElement) return;

        const tweetPath = linkElement.getAttribute('href');
        if (!tweetPath) return;

        // Extract Tweet ID
        // Format: /username/status/123456...
        const match = tweetPath.match(/status\/(\d+)/);
        if (!match) return;
        const tweetId = match[1];

        processedTweets.add(tweet);
        attachVisibilityObserver(tweet, tweetId);
    });
}

function attachVisibilityObserver(tweetElement, tweetId) {
    let timer;

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                // Optimization: Check reply count before fetching
                const replyBtn = tweetElement.querySelector('[data-testid="reply"]');
                const replyText = replyBtn ? replyBtn.innerText.trim() : '';
                // Twitter hides the count if it is 0. So empty string = 0 replies.
                // We only fetch if there is a count visible (meaning > 0)
                // Note: Sometimes it might be '1,234' or '1k', which are truthy.
                if (!replyText) {
                    observer.disconnect();
                    return;
                }

                // Eager load: 500px margin means we load before it enters viewport
                // Short debounce to avoid skipping tweets during rapid scroll
                timer = setTimeout(() => {
                    fetchComments(tweetElement, tweetId);
                    observer.disconnect();
                }, 300);
            } else {
                if (timer) clearTimeout(timer);
            }
        });
    }, {
        threshold: 0, // Trigger as soon as margin is hit
        rootMargin: '600px 0px 600px 0px' // Pre-load 600px ahead (approx 1-2 tweets)
    });

    observer.observe(tweetElement);
}

// ----------------------------------------------------------------------
// API FETCHING
// ----------------------------------------------------------------------
async function fetchComments(tweetElement, tweetId) {
    // Determine insertion point: The wrapper div (cellInnerDiv)
    // This ensures we stack BELOW the tweet, not inside its flex layout
    const wrapper = tweetElement.closest('[data-testid="cellInnerDiv"]');
    if (!wrapper) return;

    if (wrapper.querySelector('.x-comment-preview-container')) return;

    const container = document.createElement('div');
    container.className = 'x-comment-preview-container';
    container.innerHTML = '<div class="x-loading-spinner">Loading comments...</div>';

    // Append to the list item wrapper
    wrapper.appendChild(container);

    try {
        const headers = getAuthHeaders();
        // Construct API URL
        // We use the REST endpoint
        // User requested 15 items displayed, so we fetch more (60) to ensure we have enough candidates
        const apiUrl = `https://${location.hostname}/i/api/2/timeline/conversation/${tweetId}.json?include_profile_interstitial_type=1&include_blocking=1&include_blocked_by=1&include_followed_by=1&include_want_retweets=1&include_mute_edge=1&include_can_dm=1&include_can_media_tag=1&include_ext_has_nft_avatar=1&skip_status=1&cards_platform=Web-12&include_cards=1&include_ext_alt_text=true&include_quote_count=true&include_reply_count=1&tweet_mode=extended&include_entities=true&include_user_entities=true&include_ext_media_color=true&include_ext_media_availability=true&include_ext_sensitive_media_warning=true&send_error_codes=true&simple_quoted_tweet=true&count=60`;

        const response = await fetch(apiUrl, { headers });

        if (!response.ok) {
            if (response.status === 404 || response.status === 403) {
                // Determine if we should try logic B (GraphQL)
                throw new Error(`API Restricted (${response.status})`);
            }
            throw new Error(`HTTP ${response.status}`);
        }

        const data = await response.json();
        // Extract the tweet path for linking
        // The tweetElement is the article.
        // We can get the permalink from the time element again to be sure, or pass it from scanForTweets.
        // Let's re-extract to be safe.
        const timeElement = tweetElement.querySelector('time');
        const linkElement = timeElement?.closest('a');
        const tweetUrl = linkElement ? linkElement.href : `https://x.com/i/status/${tweetId}`;

        const comments = parseConversation(data, tweetId);
        renderComments(container, comments, tweetUrl);

    } catch (err) {
        console.error('Comment Fetch Error:', err);
        container.innerHTML = `<div class="error" style="color:red; font-size:12px;">Failed to load: ${err.message}</div>`;
    }
}

function getAuthHeaders() {
    // 1. Bearer Token
    // 2. CT0 (CSRF)
    const ct0 = getCookie('ct0');
    return {
        'authorization': `Bearer ${BEARER_TOKEN}`,
        'x-csrf-token': ct0,
        'x-twitter-active-user': 'yes',
        'x-twitter-client-language': 'en' // or current
    };
}

function getCookie(name) {
    const match = document.cookie.match(new RegExp('(^| )' + name + '=([^;]+)'));
    if (match) return match[2];
    // Fallback?
    return '';
}

// ----------------------------------------------------------------------
// PARSING
// ----------------------------------------------------------------------
function parseConversation(data, originalTweetId) {
    const tweets = data.globalObjects?.tweets || {};
    const users = data.globalObjects?.users || {};

    // 1. Buckets
    const level1 = []; // Direct replies
    const level2Map = {}; // Map<ParentId, List<Tweet>>

    // First pass: Classify
    Object.values(tweets).forEach(t => {
        if (t.id_str === originalTweetId) return;

        if (t.in_reply_to_status_id_str === originalTweetId) {
            level1.push(t);
        } else if (t.in_reply_to_status_id_str) {
            // Potential level 2 (we will filter later to ensure parent is level 1)
            if (!level2Map[t.in_reply_to_status_id_str]) {
                level2Map[t.in_reply_to_status_id_str] = [];
            }
            level2Map[t.in_reply_to_status_id_str].push(t);
        }
    });

    // 2. Sort Level 1 by likes
    level1.sort((a, b) => (b.favorite_count || 0) - (a.favorite_count || 0));

    const candidates = level1; // All direct candidates
    const topLevel1 = candidates.slice(0, 15);

    const comments = [];

    topLevel1.forEach(t => {
        const user = users[t.user_id_str] || {};
        const commentObj = {
            text: t.full_text,
            author: user.name,
            handle: user.screen_name,
            avatar: user.profile_image_url_https,
            likes: t.favorite_count,
            tweetUrl: `/${user.screen_name}/status/${t.id_str}`,
            subComments: []
        };

        // 3. Find top Level 2 for this Level 1
        const children = level2Map[t.id_str];
        if (children) {
            children.sort((a, b) => (b.favorite_count || 0) - (a.favorite_count || 0));
            // Take top 10 sub-comments (User requested increase from 1 to 10)
            const topChildren = children.slice(0, 10);

            topChildren.forEach(topChild => {
                const childUser = users[topChild.user_id_str] || {};
                commentObj.subComments.push({
                    text: topChild.full_text,
                    author: childUser.name,
                    handle: childUser.screen_name,
                    avatar: childUser.profile_image_url_https,
                    likes: topChild.favorite_count
                });
            });
        }

        comments.push(commentObj);
    });

    return { items: comments, total: candidates.length };
}

function renderComments(container, data, mainTweetUrl) {
    const comments = data.items;

    if (comments.length === 0) {
        container.innerHTML = '<div class="x-loading-spinner" style="color:grey;">No text comments found.</div>';
        return;
    }

    container.innerHTML = ''; // Clear

    const header = document.createElement('div');
    header.className = 'x-comment-header';
    header.textContent = 'Top Comments';
    container.appendChild(header);

    comments.forEach(c => {
        // Level 1
        const wrap = document.createElement('div');
        wrap.className = 'x-comment-item';
        wrap.innerHTML = buildCommentHTML(c, false);
        container.appendChild(wrap);

        // Level 2 (Sub-comments)
        if (c.subComments && c.subComments.length > 0) {
            c.subComments.forEach(sub => {
                const subWrap = document.createElement('div');
                subWrap.className = 'x-comment-item';
                subWrap.style.marginLeft = '42px'; // Indent (32px avatar + 10 gap) -- Actually visually better
                subWrap.style.borderLeft = '2px solid rgba(128,128,128,0.2)';
                subWrap.style.paddingLeft = '8px';
                subWrap.style.marginTop = '-4px'; // Tighter
                subWrap.innerHTML = buildCommentHTML(sub, true);
                container.appendChild(subWrap);
            });
        }
    });

    if (data.total > comments.length) {
        const viewMore = document.createElement('div');
        viewMore.style.paddingTop = '8px';
        viewMore.style.fontSize = '13px';
        viewMore.style.color = '#1d9bf0';
        viewMore.style.cursor = 'pointer';
        viewMore.textContent = `View ${data.total - comments.length} more replies`;

        viewMore.onclick = function (e) {
            e.stopPropagation();
            if (mainTweetUrl) {
                window.open(mainTweetUrl, '_blank');
            } else {
                // Fallback
                const wrapper = container.parentElement;
                if (wrapper) {
                    const article = wrapper.querySelector('article');
                    if (article) article.click();
                }
            }
        };

        container.appendChild(viewMore);
    }
}

function buildCommentHTML(c, isSub) {
    const avatarSize = isSub ? 24 : 32;
    // Removed color override for nested text to fix visibility issues
    return `
        <div style="display: flex; gap: 10px;">
            <img src="${c.avatar}" style="width: ${avatarSize}px; height: ${avatarSize}px; border-radius: 50%;">
            <div style="flex: 1; min-width: 0;">
                <div style="display: flex; justify-content: space-between;">
                    <span class="x-comment-author" style="${isSub ? 'font-size:12px' : ''}">${c.author} <span style="font-weight:normal; color:grey;">@${c.handle}</span></span>
                    <span style="font-size: 11px; color: grey;">❤ ${formatNumber(c.likes)}</span>
                </div>
                <div class="x-comment-text" style="${isSub ? 'font-size:13px;' : ''}">${formatText(c.text)}</div>
            </div>
        </div>
    `;
}

function formatNumber(num) {
    if (!num) return '0';
    if (num > 1000) return (num / 1000).toFixed(1) + 'k';
    return num;
}

function formatText(text) {
    // Remove t.co links? Keep for now.
    // Maybe handle emojis better? 
    return text;
}

// ----------------------------------------------------------------------
// BOOTSTRAP
// ----------------------------------------------------------------------
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
} else {
    init();
}
