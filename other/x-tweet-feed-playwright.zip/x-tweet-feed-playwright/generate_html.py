import json
from datetime import datetime

# 读取JSON数据
with open('temp_tweets.json', 'r', encoding='utf-8') as f:
    data = json.load(f)

# 读取模板
with open('template.html', 'r', encoding='utf-8') as f:
    template = f.read()

# 准备替换变量
generation_time = datetime.now().strftime('%Y/%m/%d %H:%M')
total_count = data['collected']
keyword_count = data['config']['keywords']
time_range = f"近{data['config']['daysAgo']}天"
min_views = data['config']['minViews']

# 替换占位符
html = template.replace('{{GENERATION_TIME}}', generation_time)
html = html.replace('{{TOTAL_COUNT}}', str(total_count))
html = html.replace('{{KEYWORD_COUNT}}', str(keyword_count))
html = html.replace('{{TIME_RANGE}}', time_range)
html = html.replace('{{MIN_VIEWS}}', str(min_views))
html = html.replace('{{TWEETS_JSON}}', json.dumps(data, ensure_ascii=False))

# 保存HTML
output_file = f'report_{datetime.now().strftime("%Y%m%d_%H%M%S")}.html'
with open(output_file, 'w', encoding='utf-8') as f:
    f.write(html)

print(f"✅ HTML报告已生成: {output_file}")
print(f"📊 推文数量: {total_count}")
