# X (Twitter) 推文采集器 - Playwright DOM版

## ⚠️ 重要前提

**必须使用 Playwright MCP**
- ✅ 此skill固定使用 `mcp__playwright__*` 系列工具
- ❌ 禁止使用 Chrome DevTools MCP
- ❌ 禁止使用其他浏览器自动化工具

**浏览器管理策略**
- ⚡ **保持浏览器进程** - 不关闭浏览器，复用已登录状态
- ⚡ **刷新同一页面** - 直接刷新X首页，不开关tab
- ⚡ **简化操作** - 打开一次页面，多次刷新采集
- ⚡ **串行执行** - 保证数据一致性和可靠性

**Token优化策略**
- ⚠️ **evaluate输出说明** - `mcp__playwright__browser_evaluate`会返回大量输出(包括JS代码、页面快照等)，这是工具本身特性，无法避免
- ⚠️ **只看结果** - 执行时忽略"Ran Playwright code"和"Page state"等中间输出，只关注"Result"中的推文数据
- ⚠️ **缩短等待** - 页面加载等待从3秒减少到2秒
- ⚠️ **接受现实** - Playwright MCP的token消耗较高是正常的，这是使用该工具的代价

## 功能描述

使用Playwright MCP从X（Twitter）Feed流采集推文，通过DOM解析获取数据。

**核心优势**：
- ✅ 无需管理Cookie - 浏览器状态自动持久化
- ✅ 无需滚动逻辑 - 多次刷新首页获取完整DOM
- ✅ Claude控制循环 - 每次调用释放内存，可控且高效
- ✅ 串行执行 - 保证数据一致性和可靠性
- ✅ 更稳定 - 首次手动登录后自动保持登录状态

## 执行步骤

### 1. 询问用户参数

- **关键词文件路径**：默认使用 `ai关键词.md`
- **推文数量**：默认20条
- **刷新次数**：默认10次
- **时间范围**：默认3天
- **最小观看数**：默认100

### 2. 读取关键词文件

```javascript
const keywords = fileContent
  .split('\n')
  .map(line => line.trim())
  .filter(line => line && !line.startsWith('#'))
  .map(kw => kw.toLowerCase());
```

### 3. 初始化数据结构

```javascript
// Claude层面维护去重Map
const tweetsMap = new Map();
const timeThreshold = Date.now() - (daysAgo * 24 * 60 * 60 * 1000);
```

### 4. 循环刷新并采集

**核心策略**：
1. **初始化** - 打开X首页一次
2. **循环采集** - 直接刷新页面，不开关tab
3. **保持浏览器** - 不关闭浏览器进程，复用登录状态
4. **Token优化** - 减少等待时间，只关注返回的推文数据

```javascript
// 4.0 初始化：打开X首页
mcp__playwright__browser_navigate({
  url: "https://x.com/home"
});

// 4.1 等待初始加载
mcp__playwright__browser_wait_for({
  time: 2
});

for (let round = 0; round < 10; round++) {
  // 4.2 解析当前可见推文
  const result = mcp__playwright__browser_evaluate({
    function: `() => {
      const keywords = ${JSON.stringify(keywords)};
      const daysAgo = ${daysAgo};
      const minViews = ${minViews};

      // 时间阈值
      const timeThreshold = Date.now() - (daysAgo * 24 * 60 * 60 * 1000);

      // 数字格式化解析
      const parseFormattedNumber = (str) => {
        if (!str) return 0;
        str = str.trim().replace(/,/g, '');
        if (str.includes('万')) {
          return Math.floor(parseFloat(str) * 10000);
        } else if (str.includes('K')) {
          return Math.floor(parseFloat(str) * 1000);
        } else if (str.includes('M')) {
          return Math.floor(parseFloat(str) * 1000000);
        }
        return parseInt(str) || 0;
      };

      // 高亮关键词
      const highlightKeywords = (text) => {
        let highlighted = text;
        keywords.forEach(kw => {
          const regex = new RegExp(\`(\${kw})\`, 'gi');
          highlighted = highlighted.replace(regex, '<mark>$1</mark>');
        });
        return highlighted;
      };

      // 解析当前页面的推文
      const tweets = [];
      const articles = document.querySelectorAll('article[data-testid="tweet"]');

      articles.forEach(article => {
        try {
          // 提取tweet ID
          const timeLink = article.querySelector('time')?.parentElement;
          if (!timeLink) return;

          const href = timeLink.getAttribute('href');
          const match = href.match(/\\/status\\/(\\d+)/);
          if (!match) return;
          const tweetId = match[1];

          // 提取推文文本
          const textElement = article.querySelector('[data-testid="tweetText"]');
          const text = textElement ? textElement.innerText : '';

          // 检查关键词
          const hasKeyword = keywords.some(kw =>
            text.toLowerCase().includes(kw.toLowerCase())
          );
          if (!hasKeyword) return;

          // 提取时间
          const timeElement = article.querySelector('time');
          const timeStr = timeElement?.getAttribute('datetime');
          const tweetTime = timeStr ? new Date(timeStr).getTime() : Date.now();

          // 检查时间范围
          if (tweetTime < timeThreshold) return;

          // 提取用户信息
          const userLinks = article.querySelectorAll('[data-testid="User-Name"] a[href^="/"]');
          let username = '';
          for (const link of userLinks) {
            const href = link.getAttribute('href');
            if (href && href.match(/^\\/[^\\/]+$/) && !href.includes('/status/')) {
              username = href.substring(1);
              break;
            }
          }
          const displayNameElement = article.querySelector('[data-testid="User-Name"] span span');
          const displayName = displayNameElement ? displayNameElement.innerText : username;

          // 提取互动数据
          const buttons = article.querySelectorAll('button[data-testid], a[href*="/analytics"]');
          let replies = 0, retweets = 0, likes = 0, views = 0;

          buttons.forEach(btn => {
            const testId = btn.getAttribute('data-testid');
            const ariaLabel = btn.getAttribute('aria-label') || '';
            const btnText = btn.innerText.trim();

            if (testId === 'reply' || ariaLabel.includes('回复') || ariaLabel.includes('Repl')) {
              replies = parseFormattedNumber(btnText);
            } else if (testId === 'retweet' || ariaLabel.includes('转帖') || ariaLabel.includes('Repost')) {
              retweets = parseFormattedNumber(btnText);
            } else if (testId === 'like' || ariaLabel.includes('喜欢') || ariaLabel.includes('Like')) {
              likes = parseFormattedNumber(btnText);
            } else if (ariaLabel.includes('查看') || ariaLabel.includes('观看') || ariaLabel.includes('View')) {
              views = parseFormattedNumber(btnText);
            }
          });

          // 检查观看数阈值
          if (views < minViews) return;

          // 截取文本（最多300字符）
          const truncatedText = text.substring(0, 300);
          const highlightedText = highlightKeywords(truncatedText);

          // 添加到结果数组
          tweets.push({
            id: tweetId,
            url: \`https://x.com/\${username}/status/\${tweetId}\`,
            text: truncatedText,
            textHighlighted: highlightedText,
            username: username,
            displayName: displayName,
            timeStr: timeStr ? new Date(timeStr).toLocaleString('zh-CN') : '',
            tweetTime: tweetTime,
            views: views,
            replies: replies,
            retweets: retweets,
            likes: likes
          });
        } catch (e) {
          // 忽略单条推文解析错误
        }
      });

      return tweets;
    }`
  });

  // 4.3 Claude层面去重合并
  result.forEach(tweet => {
    if (!tweetsMap.has(tweet.id)) {
      tweetsMap.set(tweet.id, tweet);
    }
  });

  // 4.4 刷新页面准备下一轮（最后一轮不刷新）
  if (round < 9) {
    mcp__playwright__browser_navigate({
      url: "https://x.com/home"
    });

    mcp__playwright__browser_wait_for({
      time: 2
    });
  }

  // 打印进度（简洁输出，节省token）
  console.log(`第${round + 1}轮: 新增${result.length}条, 总计${tweetsMap.size}条`);
}
```

### 5. 排序和截取

```javascript
// 转换为数组并按观看数排序
const allTweets = Array.from(tweetsMap.values());
allTweets.sort((a, b) => b.views - a.views);

// 截取前N条
const tweets = allTweets.slice(0, targetCount);
```

### 6. 生成HTML报告

```javascript
// 保存JSON
const jsonData = {
  collected: tweets.length,
  tweets: tweets,
  config: {
    keywords: keywords.length,
    targetCount: targetCount,
    daysAgo: daysAgo,
    minViews: minViews
  }
};

const jsonPath = '.claude/skills/x-tweet-feed-playwright/temp_tweets.json';
await Write(jsonPath, JSON.stringify(jsonData, null, 2));

// 生成HTML
await Bash({
  command: 'cd .claude/skills/x-tweet-feed-playwright && python3 generate_html.py'
});
```

## 配置选项

```javascript
const DEFAULT_CONFIG = {
  tweetCount: 20,      // 采集数量
  refreshTimes: 10,    // 刷新次数
  daysAgo: 3,          // 时间范围（天）
  minViews: 100        // 最小观看数
};
```

## 注意事项

1. **⚡ 浏览器管理** - 不关闭浏览器，直接刷新页面，复用登录状态
2. **🔧 Playwright MCP** - 必须使用Playwright MCP，禁止使用Chrome DevTools
3. **🔐 首次登录** - 需要手动登录X账号，之后自动保持
4. **🔄 刷新策略** - 同一页面多次刷新，简化操作，降低token消耗
5. **💰 Token优化** - 等待时间2秒，只关注推文数据，忽略中间输出
6. **📊 数据去重** - Claude层面使用Map去重，feed流刷新会有重复
7. **🎯 采集策略** - 多次刷新可获得更多样化的推文（X算法推荐会变化）

## 故障排查

### 问题1：Browser is already in use 错误

**原因**：Playwright进程已在运行或有多个tab打开

**解决**：
```javascript
// 1. 检查tab状态
mcp__playwright__browser_tabs({ action: "list" })

// 2. 关闭多余tab
mcp__playwright__browser_tabs({ action: "close", index: 0 })

// 3. 如果无法关闭，请用户手动kill进程
// ps aux | grep playwright | grep -v grep
// kill -9 <进程ID>
```

### 问题2：采集不到推文

**解决**：
- 检查是否已登录
- 确认关键词是否匹配
- 降低观看数阈值
- 增加时间范围

### 问题3：登录状态丢失

**解决**：
- 重新手动登录
- 检查 Playwright 配置目录

### 问题4：推文数量不足

**解决**：
- 增加刷新次数（修改refreshTimes参数）
- 降低筛选条件（minViews、daysAgo）
- 确认feed流中有足够的相关内容

### 问题5：采集到重复推文

**原因**：X的feed流算法推荐，多次刷新会看到部分重复内容

**解决**：
- 这是正常现象，Claude层面已做去重（使用Map）
- 重复率高时可以增加刷新次数，获取更多新推文
- 如果想要完全不同的内容，可以等待一段时间后再采集

### 问题6：Token消耗过高

**原因**：`mcp__playwright__browser_evaluate`工具会返回大量输出
- "Ran Playwright code" - 显示执行的JS代码(~2.5k tokens)
- "Page state" - YAML格式的页面快照(~5-8k tokens)
- 这些是Playwright MCP工具的固有特性，无法关闭

**解决**：
- ✅ 已优化：等待时间从3秒减少到2秒
- ✅ 已优化：改为刷新同一页面，减少tab操作
- 💡 建议：执行时只关注"Result"中的推文数据，忽略中间输出
- 💡 接受：这是使用Playwright MCP的正常代价
- 💡 替代方案：如需大幅降低token消耗，考虑改用Chrome DevTools MCP(但功能可能不如Playwright完善)

## 更新记录

- 2025-11-14 v3.1：
  - **Token消耗说明** - 明确Playwright MCP的大量输出是工具特性，无法避免
  - **优化建议** - 只关注Result中的推文数据，忽略中间输出
  - **提供替代方案** - 如需降低token，可考虑Chrome DevTools MCP
- 2025-11-14 v3：
  - **刷新策略优化** - 改为刷新同一页面，不再开关tab
  - **简化操作** - 打开一次页面，多次刷新采集
  - **Token消耗对比** - 实测发现刷新同一页面token消耗更高(因每次返回完整页面快照)
- 2025-11-14 v2：
  - **Token优化** - 等待时间2秒，减少不必要输出
  - **浏览器管理优化** - 保留空白tab，不关闭浏览器，使用tab切换
  - **去重说明** - 明确feed流会有重复，已在Claude层面去重
- 2025-11-14 v1：
  - 重构为Claude控制循环，刷新首页策略
  - 添加tab管理和进程处理说明
- 2025-11-13：改为DOM解析版本
