# X (Twitter) 推文采集器 - Feed流模式

## 功能描述

这个skill用于**从Feed流**采集X（Twitter）上符合特定关键词条件的推文，并生成美观的HTML报告。

**数据来源**：用户的个人Feed流（Home时间线）

支持功能：
1. **关键词过滤** - 根据关键词文件筛选推文
2. **时间筛选** - 只采集指定天数内的推文
3. **热度筛选** - 按观看数/互动数筛选
4. **自动刷新** - 连续3次无新推文时自动刷新页面
5. **HTML报告** - 生成卡片式布局的美观报告

## 使用方法

### 准备工作

1. **准备关键词文件**：创建一个文本文件，每行一个关键词
2. **获取Cookie**：在X网站登录后，从浏览器开发者工具中复制Cookie字符串
3. **确定筛选条件**：推文数量、时间范围、最小观看数

### 执行步骤

当用户请求采集推文时，按以下步骤执行：

#### 1. 读取Cookie和询问用户参数

首先尝试从 `cookie.txt` 文件读取Cookie：

```javascript
// 读取cookie文件
const cookiePath = '.claude/skills/x-tweet-collector/cookie.txt';
let cookieContent = '';

try {
  cookieContent = await Read(cookiePath);
  // 提取非注释行的cookie内容
  const cookieLines = cookieContent
    .split('\n')
    .filter(line => line.trim() && !line.trim().startsWith('#'));

  if (cookieLines.length === 0) {
    // cookie文件为空，提示用户配置
    throw new Error('Cookie文件为空，请配置cookie.txt');
  }

  cookieContent = cookieLines.join('; ');
} catch (error) {
  // cookie文件不存在或读取失败，提示用户
  告知用户："未找到有效的Cookie配置，请按以下步骤配置：
  1. 在浏览器登录 https://x.com
  2. 按F12打开开发者工具，在Console输入: copy(document.cookie)
  3. 将复制的内容粘贴到 .claude/skills/x-tweet-collector/cookie.txt 文件中"

  // 等待用户配置完成后再继续
  return;
}
```

然后使用 `AskUserQuestion` 工具询问其他参数：

- **关键词文件路径**：包含搜索关键词的文件（如：ai关键词.md）
- **推文数量**（可选）：需要采集多少条推文，默认20条
- **时间范围**（可选）：采集多少天内的推文，默认3天
- **最小观看数**（可选）：推文的最小观看数阈值，默认100

注意：不再询问Cookie，直接从文件读取。如果后续采集失败（提示登录），再告知用户更新cookie.txt文件。

#### 2. 读取关键词文件

使用 `Read` 工具读取关键词文件内容，提取所有关键词到数组中。

示例关键词处理：
```javascript
// 读取文件内容后，按行分割并过滤空行
const keywords = fileContent
  .split('\n')
  .map(line => line.trim())
  .filter(line => line && !line.startsWith('#'))
  .map(kw => kw.toLowerCase());
```

#### 3. 打开X网站并设置Cookie

使用Chrome DevTools MCP工具：

```javascript
// 3.1 打开新页面
mcp__chrome-devtools__new_page({
  url: "https://x.com",
  timeout: 30000
})

// 3.2 设置Cookie（使用从cookie.txt读取的内容）
mcp__chrome-devtools__evaluate_script({
  function: `() => {
    // 解析Cookie字符串并设置
    const cookieStr = '${cookieContent}';  // 从cookie.txt文件读取
    const cookies = cookieStr.split('; ');
    cookies.forEach(cookie => {
      const [name, ...valueParts] = cookie.split('=');
      const value = valueParts.join('=');
      document.cookie = \`\${name}=\${value}; domain=.x.com; path=/\`;
    });
    return 'Cookies set successfully';
  }`
})

// 3.3 刷新页面使Cookie生效
mcp__chrome-devtools__navigate_page({
  type: "reload",
  timeout: 30000
})
```

#### 4. 采集推文数据

使用 `evaluate_script` 执行采集脚本：

```javascript
mcp__chrome-devtools__evaluate_script({
  function: `async () => {
    // 关键词列表（从用户文件读取）
    const keywords = ${JSON.stringify(keywords)};

    // 配置参数
    const targetCount = ${tweetCount}; // 目标数量，默认20
    const daysAgo = ${daysAgo}; // 天数，默认3
    const minViews = ${minViews}; // 最小观看数，默认100

    const tweets = [];
    const seenTweetIds = new Set();
    const timeThreshold = Date.now() - (daysAgo * 24 * 60 * 60 * 1000);

    // 辅助函数：解析时间
    function parseTime(timeStr) {
      const now = Date.now();
      if (timeStr.includes('小时') || timeStr.includes('hour')) {
        const hours = parseInt(timeStr);
        return now - (hours * 60 * 60 * 1000);
      } else if (timeStr.includes('分钟') || timeStr.includes('minute') || timeStr.includes('min')) {
        const mins = parseInt(timeStr);
        return now - (mins * 60 * 1000);
      } else if (timeStr.includes('秒') || timeStr.includes('second') || timeStr.includes('sec')) {
        const secs = parseInt(timeStr);
        return now - (secs * 1000);
      }
      // 对于日期格式，视为最近发布
      return now;
    }

    // 辅助函数：解析观看数
    function parseViews(viewStr) {
      if (!viewStr) return 0;
      viewStr = viewStr.replace(/,/g, '').replace(/\\s/g, '');

      // 处理中文
      if (viewStr.includes('万')) {
        return parseFloat(viewStr) * 10000;
      }
      // 处理英文
      if (viewStr.includes('K')) {
        return parseFloat(viewStr) * 1000;
      }
      if (viewStr.includes('M')) {
        return parseFloat(viewStr) * 1000000;
      }
      return parseInt(viewStr) || 0;
    }

    // 辅助函数：检查是否包含关键词
    function hasKeyword(text) {
      const lowerText = text.toLowerCase();
      return keywords.some(kw => lowerText.includes(kw));
    }

    // 辅助函数：截取文本（最多5行）
    function truncateText(text, maxLines = 5, maxChars = 300) {
      if (!text) return '';

      // 先按换行符分割
      const lines = text.split('\n');

      // 如果行数少于等于5行，检查总字符数
      if (lines.length <= maxLines) {
        return text.length > maxChars ? text.substring(0, maxChars) + '...' : text;
      }

      // 取前5行
      const truncated = lines.slice(0, maxLines).join('\n');
      return truncated.length > maxChars ? truncated.substring(0, maxChars) + '...' : truncated + '...';
    }

    // 辅助函数：高亮关键词
    function highlightKeywords(text) {
      let highlighted = text;
      keywords.forEach(kw => {
        const regex = new RegExp(\`(\${kw})\`, 'gi');
        highlighted = highlighted.replace(regex, '<mark>$1</mark>');
      });
      return highlighted;
    }

    // 收集推文的函数
    function collectTweets() {
      const articles = document.querySelectorAll('article[data-testid="tweet"]');
      let newCount = 0;

      articles.forEach(article => {
        try {
          // 获取推文链接
          const timeLink = article.querySelector('time')?.parentElement;
          if (!timeLink) return;

          const tweetUrl = timeLink.href;
          const tweetId = tweetUrl.split('/status/')[1]?.split('?')[0];
          if (!tweetId || seenTweetIds.has(tweetId)) return;

          // 获取推文文本
          const textElement = article.querySelector('[data-testid="tweetText"]');
          const tweetText = textElement?.innerText || '';

          // 检查是否包含关键词
          if (!hasKeyword(tweetText)) return;

          // 获取时间
          const timeElement = article.querySelector('time');
          const timeStr = timeElement?.parentElement?.innerText || '';
          const tweetTime = parseTime(timeStr);

          // 检查是否在指定天数内
          if (tweetTime < timeThreshold) return;

          // 获取观看数
          const viewsElement = article.querySelector('[href*="/analytics"]');
          const viewsText = viewsElement?.innerText || '0';
          const views = parseViews(viewsText);

          // 检查观看数是否达标
          if (views < minViews) return;

          // 获取用户信息
          const userLink = article.querySelector('[data-testid="User-Name"] a');
          const username = userLink?.href.split('/').pop() || '';
          const displayName = userLink?.innerText || username;

          // 获取互动数据
          const replyElement = article.querySelector('[data-testid="reply"]');
          const replies = parseInt(replyElement?.getAttribute('aria-label')?.match(/\\d+/)?.[0] || '0');

          const retweetElement = article.querySelector('[data-testid="retweet"]');
          const retweets = parseInt(retweetElement?.getAttribute('aria-label')?.match(/\\d+/)?.[0] || '0');

          const likeElement = article.querySelector('[data-testid="like"]');
          const likes = parseInt(likeElement?.getAttribute('aria-label')?.match(/\\d+/)?.[0] || '0');

          // 截取文本（最多5行）
          const truncatedText = truncateText(tweetText);

          seenTweetIds.add(tweetId);
          tweets.push({
            id: tweetId,
            url: tweetUrl,
            text: truncatedText,
            textHighlighted: highlightKeywords(truncatedText),
            username: username,
            displayName: displayName,
            timeStr: timeStr,
            tweetTime: tweetTime,
            views: views,
            replies: replies,
            retweets: retweets,
            likes: likes
          });
          newCount++;

        } catch (e) {
          console.error('Error processing tweet:', e);
        }
      });

      return newCount;
    }

    // 初始收集
    collectTweets();

    // 滚动并收集更多推文
    let scrollAttempts = 0;
    const maxScrolls = 50; // 最多滚动50次
    let noNewTweetsCount = 0;
    let hasRefreshed = false; // 是否已经刷新过页面

    while (tweets.length < targetCount && scrollAttempts < maxScrolls) {
      // 滚动到页面底部
      window.scrollTo(0, document.body.scrollHeight);

      // 等待新内容加载
      await new Promise(resolve => setTimeout(resolve, 2000));

      // 收集新推文
      const newTweets = collectTweets();
      scrollAttempts++;

      // 如果连续3次滚动都没有新推文
      if (newTweets === 0) {
        noNewTweetsCount++;
        if (noNewTweetsCount >= 3) {
          // 如果还没有刷新过页面，尝试刷新一次
          if (!hasRefreshed) {
            console.log('连续3次无新推文，刷新页面尝试加载更多...');
            location.reload();
            // 等待页面重新加载
            await new Promise(resolve => setTimeout(resolve, 3000));
            hasRefreshed = true;
            noNewTweetsCount = 0; // 重置计数
            continue;
          } else {
            // 刷新后仍无新推文，停止采集
            console.log('刷新后仍无新推文，停止采集');
            break;
          }
        }
      } else {
        noNewTweetsCount = 0;
      }
    }

    // 按时间排序（最新的在前）
    tweets.sort((a, b) => b.tweetTime - a.tweetTime);

    return {
      collected: tweets.length,
      tweets: tweets.slice(0, targetCount),
      config: {
        keywords: keywords.length,
        targetCount: targetCount,
        daysAgo: daysAgo,
        minViews: minViews
      }
    };
  }`
})
```

#### 5. 生成HTML报告

**重要**：使用Python脚本生成HTML报告，避免JSON转义问题。

执行步骤：

```javascript
// 第一步：将采集的数据保存为临时JSON文件
const jsonPath = '.claude/skills/x-tweet-collector/temp_tweets.json';
const jsonData = JSON.stringify(
  {
    collected: tweets.length,
    tweets: tweets.slice(0, targetCount),
    config: {
      keywords: keywords.length,
      targetCount: targetCount,
      daysAgo: daysAgo,
      minViews: minViews
    }
  },
  null,
  2
);

await Write(jsonPath, jsonData);
console.log('JSON数据已保存:', jsonPath);
```

```bash
# 第二步：使用Python脚本生成HTML报告
cd .claude/skills/x-tweet-collector
python3 generate_report.py temp_tweets.json

# 脚本会自动生成：tweets-YYYY-MM-DD-HHMMSS.html（在当前目录）
```

**generate_report.py 说明**：
- 自动处理JSON特殊字符转义
- 自动生成带时间戳的文件名，直接输出到当前目录
- 可指定输出路径：`python3 generate_report.py temp_tweets.json custom.html`
- 支持中文字符，无乱码

#### 6. 返回结果

告知用户：
- 成功采集的推文数量
- HTML报告保存位置
- 可以直接在浏览器打开查看

## 输出格式

### HTML报告特性

1. **响应式设计** - 支持桌面、平板、手机
2. **卡片式布局** - 每条推文一个卡片
3. **关键词高亮** - 匹配的关键词用黄色背景标记
4. **互动数据** - 显示观看数、点赞、转发、回复
5. **搜索功能** - 实时搜索推文内容
6. **排序功能** - 按时间/观看数/互动数排序
7. **一键跳转** - 点击卡片或链接按钮在新标签打开

### 卡片内容包含

- 用户头像占位符和用户名
- 发布时间
- 推文内容（关键词高亮）
- 统计数据（观看、点赞、转发、回复）
- 跳转链接按钮

## 文件说明

- `skill.md` - 本说明文档（Skill定义文件）
- `README.md` - 用户友好的使用文档
- `template.html` - HTML报告模板
- `reports/` - 生成的报告保存目录

## 配置选项

### 默认值

```javascript
const DEFAULT_CONFIG = {
  tweetCount: 20,      // 采集数量
  daysAgo: 3,          // 时间范围（天）
  minViews: 100,       // 最小观看数
  scrollDelay: 2000,   // 滚动延迟（毫秒）
  maxScrolls: 50       // 最大滚动次数
};
```

用户可以通过参数覆盖默认值。

## 使用限制

1. **需要登录** - 必须提供有效的Cookie
2. **网络稳定** - 需要稳定的网络连接
3. **时间消耗** - 采集20条推文大约需要1-3分钟
4. **X限制** - 可能受到X平台的速率限制

## 注意事项

1. **Cookie安全** - Cookie包含敏感信息，不要泄露给他人
2. **Cookie有效期** - Cookie可能过期，需要重新获取
3. **采集频率** - 避免频繁采集，可能被X限制
4. **数据准确性** - 观看数等数据为采集时的快照
5. **推文删除** - 已采集的推文可能被作者删除

## 故障排查

### 问题1：Cookie无效

**现象**：无法加载feed流，显示登录页面

**解决**：
- 重新登录X网站
- 从浏览器开发者工具复制最新的Cookie
- 确保Cookie字符串完整

### 问题2：采集不到推文

**现象**：返回的推文数量为0或很少

**解决**：
- 检查关键词是否太严格
- 调整时间范围（增加天数）
- 降低最小观看数阈值
- 确认feed流中确实有符合条件的内容

### 问题3：页面加载缓慢

**现象**：脚本执行时间过长

**解决**：
- 检查网络连接
- 减少采集数量
- 增加滚动延迟时间

## 快速开始示例

```
用户: 帮我采集X上关于AI的推文

Claude执行步骤：
1. 询问关键词文件路径 -> "ai关键词.md"
2. 询问Cookie -> 用户提供
3. 使用默认配置（20条、3天、100观看）
4. 打开X网站，设置Cookie
5. 滚动feed流采集数据
6. 生成HTML报告
7. 返回结果："成功采集20条推文，报告已保存到 reports/tweets-xxx.html"
```

## 更新记录

- 2025-11-07：创建skill，支持关键词过滤、时间筛选、HTML报告生成
