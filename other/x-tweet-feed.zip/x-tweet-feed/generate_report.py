#!/usr/bin/env python3
"""
X推文采集报告生成器

读取推文JSON数据并生成美观的HTML报告
"""

import json
import sys
from datetime import datetime
from pathlib import Path


def generate_html_report(tweets_data, output_path=None):
    """
    生成HTML报告

    Args:
        tweets_data: 推文数据字典
        output_path: 输出文件路径（可选）

    Returns:
        str: 生成的HTML文件路径
    """

    # 获取当前脚本所在目录
    script_dir = Path(__file__).parent
    template_path = script_dir / "template.html"

    # 读取HTML模板
    with open(template_path, 'r', encoding='utf-8') as f:
        template = f.read()

    # 准备替换数据
    generation_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    total_count = tweets_data.get('collected', len(tweets_data.get('tweets', [])))
    config = tweets_data.get('config', {})
    keyword_count = config.get('keywords', 0)
    days_ago = config.get('daysAgo', 3)
    min_views = config.get('minViews', 100)

    # 将推文数据转换为安全的JSON字符串
    # ensure_ascii=False 保持中文字符
    # indent=None 生成紧凑的JSON（减小文件大小）
    tweets_json = json.dumps(tweets_data, ensure_ascii=False, indent=None)

    # 替换模板中的占位符
    html = template.replace('{{TWEETS_JSON}}', tweets_json)
    html = html.replace('{{GENERATION_TIME}}', generation_time)
    html = html.replace('{{TOTAL_COUNT}}', str(total_count))
    html = html.replace('{{KEYWORD_COUNT}}', str(keyword_count))
    html = html.replace('{{TIME_RANGE}}', f'最近 {days_ago} 天')
    html = html.replace('{{MIN_VIEWS}}', f'≥ {min_views}')

    # 确定输出路径
    if output_path is None:
        # 输出到项目根目录（.claude/skills/x-tweet-feed -> .claude/skills -> .claude -> 项目根）
        project_root = script_dir.parent.parent.parent
        timestamp = datetime.now().strftime('%Y-%m-%d-%H%M%S')
        output_path = project_root / f"tweets-feed-{timestamp}.html"
    else:
        output_path = Path(output_path)

    # 写入HTML文件
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(html)

    return str(output_path)


def main():
    """主函数"""
    if len(sys.argv) < 2:
        print("用法: python generate_report.py <tweets_data.json> [output.html]")
        print("示例: python generate_report.py tweets_data.json")
        sys.exit(1)

    # 读取推文数据
    input_file = sys.argv[1]
    try:
        with open(input_file, 'r', encoding='utf-8') as f:
            tweets_data = json.load(f)
    except FileNotFoundError:
        print(f"错误: 文件 '{input_file}' 不存在")
        sys.exit(1)
    except json.JSONDecodeError as e:
        print(f"错误: JSON解析失败 - {e}")
        sys.exit(1)

    # 生成HTML报告
    output_file = sys.argv[2] if len(sys.argv) > 2 else None
    try:
        output_path = generate_html_report(tweets_data, output_file)
        print(f"✅ HTML报告生成成功: {output_path}")
        print(f"📊 推文总数: {tweets_data.get('collected', 0)}")
    except Exception as e:
        print(f"错误: 生成报告失败 - {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
